--SALES ANALYSIS

--TOTAL SALES BY STORE

SELECT DISTINCT(s.store_name)
FROM sales.orders as o
  JOIN sales.stores as s 
    ON o.store_id = s.store_id




SELECT s.store_name, sum(o.order_status) AS total_sales
FROM sales.orders as o
  JOIN sales.stores as s 
    ON o.store_id = s.store_id
GROUP BY s.store_name
ORDER BY total_sales  DESC




--MONTHLY SALES TREND

SELECT *
FROM sales.orders o


SELECT YEAR(o.order_date) AS year, MONTH(o.order_date) AS month, SUM(o.order_status) AS total_sales
FROM sales.orders o
GROUP BY YEAR(o.order_date), MONTH(o.order_date)
ORDER BY year, month


--PRODUCT ANALYSIS

--A. TOP SELLING PRODUCT


select top(10) p.product_name, SUM(od.quantity) as total_quantity
from sales.order_items as od
   join production.products p
      on od.product_id = p.product_id
group by product_name
order by total_quantity DESC;



--B. STOCK LEVEL PRODUCT
select p.product_name, s.store_name, st.quantity
from production.stocks st
   join production.products p 
       on st.product_id = p.product_id
   join sales.stores s 
       on st.store_id = s.store_id
order by p.product_name, s.store_name;



--C. CUSTOMER ANALYSIS
 
 --TOP CUSTOMERS BY PURCHASE AMOUNT


 SELECT TOP(10) c.first_name, c.last_name, SUM(oi.list_price) as total_spent
 FROM sales.orders o
    JOIN sales.customers c 
	     ON o.customer_id = c.customer_id
    JOIN sales.order_items oi
	     ON o.order_id = oi.order_id
GROUP BY c.first_name, c.last_name
ORDER BY total_spent DESC


--1. CLASSIFTYING SALES PERFORMANCE
--Suppose you want to classify stores based on their total sales into categories like LOW, MEDIUM, HIGH.

select s.store_name,
       sum(o.order_status) as total_sales,
	   case
	       when sum(o.order_status) < 1000 then 'Low'
		   when sum(o.order_status) between 1001 and 3000 then 'Medium'
		   else 'High'
		end as sales_performance
from sales.orders o
   join sales.stores s
       on o.store_id = s.store_id
group by s.store_name
order by total_sales desc;



--2. Customer segment 
--Segment customers based on theit total spending


 SELECT  c.first_name, c.last_name, 
        SUM(oi.list_price) as total_spent,
		case 
		    when SUM(oi.list_price) < 5000 then 'Bronze'
			when SUM(oi.list_price) Between 5000 and 15000 then 'Silver'
			when SUM(oi.list_price) between 15000 and 20000 then 'Gold'
			else 'Platium'
		end as customer_segment
 FROM sales.orders o
    JOIN sales.customers c 
	     ON o.customer_id = c.customer_id
    JOIN sales.order_items oi
	     ON o.order_id = oi.order_id
GROUP BY c.first_name, c.last_name
ORDER BY total_spent DESC



--3. Inventory Status
--classify inventory status for each product in each store


select p.product_name, s.store_name, 
       st.quantity,
	   case
	       when  st.quantity = 0 then 'Out of Stock'
		   when  st.quantity < 20 then 'Low Stock'
		   else 'In Stock'
	  end as inventory_status
from production.stocks st
   join production.products p 
       on st.product_id = p.product_id
   join sales.stores s 
       on st.store_id = s.store_id
order by p.product_name, s.store_name;



--4.Monthly sales Comparisons

SELECT  MONTH(o.order_date) AS month, 
        YEAR(o.order_date) AS year,
		 SUM(o.order_status) AS total_sales,
		CASE
		    WHEN LAG(SUM(o.order_status)) OVER (PARTITION BY MONTH(o.order_date) ORDER BY YEAR(o.order_date)) IS NULL THEN 'N/A'
			WHEN SUM(o.order_status) > LAG(SUM(o.order_status))  OVER (PARTITION BY MONTH(o.order_date) ORDER BY YEAR(o.order_date)) THEN 'Increase'
			ELSE 'Decrease'
	   END AS sales_trend
FROM sales.orders o
GROUP BY MONTH(o.order_date), YEAR(o.order_date)
ORDER BY year, month



select order_id, order_date, customer_id, order_status
from sales.orders
where order_date between '2016-01-01' and '2023-12-31'


--FINDING CUSTOMERS FROM SPECIFIC CITY

select first_name, last_name, street
from sales.customers
where city = 'New York'


--FIND CUSTOMERS WHOSE LAST NAME START WITH A SPECIFIC LETTER

select customer_id, first_name, last_name
from sales.customers
where last_name like 's%'


--FIND PRODUCT THAT HAVE NO ASSOCIATED DISCOUNT

select *
from sales.order_items
where discount is NULL;


--A. Filtering Sales Order by a Specific Store and Data Range

select order_id, order_date, customer_id, order_status
from sales.orders
where store_id = 1 and order_date between '2016-01-01' and '2016-06-30'


 SELECT c.first_name, c.last_name, SUM(oi.list_price) as total_spent
 FROM sales.orders o
    JOIN sales.customers c 
	     ON o.customer_id = c.customer_id
    JOIN sales.order_items oi
	     ON o.order_id = oi.order_id
WHERE	oi.list_price > 5000
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_spent DESC